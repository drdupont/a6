// Express initialization
var express = require('express');
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI ||   process.env.MONGOHQ_URL || 
'mongodb://maxtishler:talbot62@dharma.mongohq.com:10007/a5scores';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

app.get('/', function (request, response) {
// Root index, displays all score data.
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	response.set('Content-Type', 'text/html');
	score_display = "";
	db.collection('scores', function(error, collection) {
		collection.find().toArray(function(err, cursor){
			if(!err){
				for(var count = 0; count < cursor.length; count++){
					score_display += cursor[count].game_title + " " + 
					cursor[count].username + " " + cursor[count].score + " " 
					+ cursor[count].created_at + '</br>';
				}
				response.send('<h1>Showing all game score data</h1> </br>' + score_display);
			}
		});
	});
});

app.post('/submit.json', function(request, response) {
// Submits score and respective data: game_title, username, and score.
// Missing data verification methods!
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	response.set('Content-Type', 'text/html');
	db.collection('scores', function(err, collection){
		collection.insert({
			game_title: request.body.game_title,
			username: request.body.username,
			score: request.body.score,
			created_at: Date()
		});
	});
});

app.get('/highscores.json', function(request, response) {
// Should take in a game_title query and return score results as a json, but
// currently does not work.
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	response.set('Content-Type', 'text/html');
	score_display = "";
	
	input = request.query.game_title;
	response.send(input);
	
	db.collection('scores', function(err, collection){
		collection.find({game_title: {'$in': input}}).toArray(function(err, cursor){
			if(!err){
				for(var count = 0; count < cursor.length; count++){
					score_display += cursor[count].game_title + " " + 
					cursor[count].username + " " + cursor[count].score + " " 
					+ cursor[count].created_at + '</br>';
				}
				response.send(score_display);
				//response.send([{game_title:...,score:....,....}]);
			}
		});
	});
});

app.get('/usersearch', function(request, response) {
// Search for a username, display scores
	response.set('Content-Type', 'text/html');
	response.send('<form name="search" action="search_results" method="post"> Enter Username: <input type = "text" id = "Username"> <br> <input type = "submit" id ="submit"> </form>');	
});

app.post('/search_results', function(request, response) {
	response.set('Content-Type', 'text/html');
	score_display = "";
	console.log(request.body);
	db.collection('scores', function(error, collection) {
		collection.find({username: {'$in': request.body}}).toArray(function(err, cursor){
			if(!err){
				for(var count = 0; count < cursor.length; count++){
					score_display += cursor[count].game_title + " " + 
					cursor[count].username + " " + cursor[count].score + " " 
					+ cursor[count].created_at + '</br>';
				}
				response.send('<h1>Showing search data...</h1> </br>' + score_display);
			}
		});
	});
});

app.listen(process.env.PORT || 3000);